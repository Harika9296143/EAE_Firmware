#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

/* ------------------ CAN FRAME ------------------ */
typedef struct {
    uint32_t id;        // CAN Identifier (11-bit for standard)
    uint8_t dlc;        // Data Length Code (0-8)
    uint8_t data[8];    // Data payload
} CANFrame;

/* ------------------ CAN BUS SIMULATION ------------------ */
#define BUS_CAPACITY 32

typedef struct {
    CANFrame frames[BUS_CAPACITY];
    int head;
    int tail;
    int count;
} CANBus;

void canbus_init(CANBus *bus) {
    memset(bus, 0, sizeof(*bus));
}

int canbus_send(CANBus *bus, const CANFrame *frame) {
    if (bus->count >= BUS_CAPACITY) return -1; // Bus full
    bus->frames[bus->tail] = *frame;
    bus->tail = (bus->tail + 1) % BUS_CAPACITY;
    bus->count++;
    return 0;
}

int canbus_receive(CANBus *bus, CANFrame *out_frame) {
    if (bus->count <= 0) return 0; // nothing to read
    *out_frame = bus->frames[bus->head];
    bus->head = (bus->head + 1) % BUS_CAPACITY;
    bus->count--;
    return 1;
}

/* ------------------ SIMULATED NODES ------------------ */

typedef struct {
    float coolant_temp;
    uint8_t pump_cmd;
    uint8_t fan_cmd;
} ControllerNode;

typedef struct {
    float inverter_temp;
    float dc_voltage;
    float current;
    uint8_t derate_flag;
} InverterNode;

/* CAN IDs (example) */
#define CAN_ID_COOLING_CMD   0x100
#define CAN_ID_INVERTER_STAT 0x200

/* ------------------ ENCODING / DECODING ------------------ */

void send_cooling_command(CANBus *bus, ControllerNode *ctrl) {
    CANFrame f = {0};
    f.id = CAN_ID_COOLING_CMD;
    f.dlc = 4;

    // Pack simple data
    int16_t temp_x10 = (int16_t)(ctrl->coolant_temp * 10);
    f.data[0] = temp_x10 >> 8;
    f.data[1] = temp_x10 & 0xFF;
    f.data[2] = ctrl->pump_cmd;
    f.data[3] = ctrl->fan_cmd;

    canbus_send(bus, &f);

    printf("[Controller] Sent COOLING_CMD: Temp=%.1fC Pump=%d Fan=%d\n",
           ctrl->coolant_temp, ctrl->pump_cmd, ctrl->fan_cmd);
}

void receive_cooling_command(InverterNode *inv, CANBus *bus) {
    CANFrame f;
    while (canbus_receive(bus, &f)) {
        if (f.id == CAN_ID_COOLING_CMD) {
            int16_t temp_x10 = (f.data[0] << 8) | f.data[1];
            float coolant_temp = temp_x10 / 10.0f;
            uint8_t pump = f.data[2];
            uint8_t fan = f.data[3];
            printf("  [Inverter] Received COOLING_CMD: Temp=%.1fC Pump=%d Fan=%d\n",
                   coolant_temp, pump, fan);
            // Inverter could adjust cooling behavior or log data here.
        }
    }
}

void send_inverter_status(CANBus *bus, InverterNode *inv) {
    CANFrame f = {0};
    f.id = CAN_ID_INVERTER_STAT;
    f.dlc = 8;

    int16_t temp_x10 = (int16_t)(inv->inverter_temp * 10);
    int16_t volt_x10 = (int16_t)(inv->dc_voltage * 10);
    int16_t curr_x10 = (int16_t)(inv->current * 10);

    f.data[0] = temp_x10 >> 8;
    f.data[1] = temp_x10 & 0xFF;
    f.data[2] = volt_x10 >> 8;
    f.data[3] = volt_x10 & 0xFF;
    f.data[4] = curr_x10 >> 8;
    f.data[5] = curr_x10 & 0xFF;
    f.data[6] = inv->derate_flag;
    f.data[7] = 0; // reserved

    canbus_send(bus, &f);

    printf("  [Inverter] Sent STATUS: Temp=%.1fC Volt=%.1fV Curr=%.1fA Derate=%d\n",
           inv->inverter_temp, inv->dc_voltage, inv->current, inv->derate_flag);
}

void receive_inverter_status(ControllerNode *ctrl, CANBus *bus) {
    CANFrame f;
    while (canbus_receive(bus, &f)) {
        if (f.id == CAN_ID_INVERTER_STAT) {
            int16_t temp_x10 = (f.data[0] << 8) | f.data[1];
            int16_t volt_x10 = (f.data[2] << 8) | f.data[3];
            int16_t curr_x10 = (f.data[4] << 8) | f.data[5];
            uint8_t derate = f.data[6];
            printf("[Controller] Received INVERTER_STAT: Temp=%.1fC Volt=%.1fV Curr=%.1fA Derate=%d\n",
                   temp_x10 / 10.0f, volt_x10 / 10.0f, curr_x10 / 10.0f, derate);
        }
    }
}

/* ------------------ MAIN SIMULATION ------------------ */

int main(void) {
    srand(time(NULL));

    CANBus bus_ctrl_to_inv, bus_inv_to_ctrl;
    canbus_init(&bus_ctrl_to_inv);
    canbus_init(&bus_inv_to_ctrl);

    ControllerNode ctrl = {.coolant_temp = 35.0f, .pump_cmd = 1, .fan_cmd = 50};
    InverterNode inv = {.inverter_temp = 45.0f, .dc_voltage = 320.0f, .current = 25.0f, .derate_flag = 0};

    printf("Starting CAN bus simulation...\n\n");

    for (int tick = 0; tick < 10; ++tick) {
        printf("\n=== TIME STEP %d ===\n", tick);

        // Controller sends cooling command every cycle
        send_cooling_command(&bus_ctrl_to_inv, &ctrl);

        // Inverter receives it
        receive_cooling_command(&inv, &bus_ctrl_to_inv);

        // Inverter updates values and sends status back
        inv.inverter_temp += (rand() % 5 - 2) * 0.2f;
        send_inverter_status(&bus_inv_to_ctrl, &inv);

        // Controller receives inverter status
        receive_inverter_status(&ctrl, &bus_inv_to_ctrl);

        // Simulate slight environment change
        ctrl.coolant_temp += (rand() % 3 - 1) * 0.3f;
    }

    printf("\nSimulation complete.\n");
    return 0;
}